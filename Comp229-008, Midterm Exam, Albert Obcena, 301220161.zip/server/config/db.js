module.exports = {
  //local MongoDB deployment ->
  URI: "mongodb://127.0.0.1/Emp",
  //URI: "mongodb://127.0.0.1/emp",
};
