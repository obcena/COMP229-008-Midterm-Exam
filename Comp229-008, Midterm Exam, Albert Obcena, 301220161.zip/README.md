# COMP229-F2022-MidTerm Test

## Welcome to the MidTerm Project - The Employee Information App

please use **`npm install`** to install project dependencies
